//Menna Nabil

import 'package:flutter/material.dart';

Color mainColor = Colors.red;