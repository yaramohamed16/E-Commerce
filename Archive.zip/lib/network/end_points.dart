// Rana
const HOME = 'home';
// Nadeen
const FAVORITES= 'favorites';
//Menna
const LOGIN = 'login';
const Register = 'register';
// Yara
const PROFILE = 'profile';
const UPDATEPROFILE = 'update-profile';