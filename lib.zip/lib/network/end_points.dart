const HOME = 'home';
const FAVORITES= 'favorites';
const LOGIN = 'login';
const Register = 'register';
const PROFILE = 'profile';
const UPDATEPROFILE = 'update-profile';